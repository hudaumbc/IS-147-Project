/**
 * Created by KhoaFaise on 4/26/17.
 */

import java.util.Scanner;
import java.util.Random;
public class RockPaperScissors {
    public static void main(String [] args){
        //create a scanner
        Scanner user = new Scanner(System.in);
        int computer = (int)(Math.random() * 3);
        final int Rock = 1;
        final int Paper = 2;
        final int Scissors = 3;

        //prompt the user to enter rock, paper, or scissors
        System.out.print("\nPick Rock (1), Paper (2), Scissors (3)");
        int player = user.nextInt();

        //computer choice
        System.out.print("Computer chooses: " + computer);

        switch (player){
            case Scissors:
                if (computer == Scissors){
                    System.out.println(" Scissors, it's a tie!");
                }//end if
                else{
                    if (computer == Rock){
                        System.out.println(" Rock crushes Scissors, you lose!");
                    }//end if
                    else{
                        System.out.println(" Scissors cut paper, you win!");
                    }//end else
                }//end else
                break;

            case Rock:
                if (computer == Scissors){
                    System.out.println(" Rock crushes scissors, you win!");
                }//end if
                else {
                    if (computer == Rock){
                        System.out.println(" Rock, it's a tie!");
                    }//end if
                    else {
                        System.out.println(" Paper wraps rock, you lose!");
                    }//end else
                }//end else, Rock
                break;

            case Paper:
                if (computer == Scissors){
                    System.out.println(" Scissors cuts paper, you lose!");
                }//end if
                else {
                    if (computer == Rock){
                        System.out.println(" Paper beats rock, you win!");
                    }//end if

                    else {
                        System.out.println(" Paper, tie!");
                    }//end if
                }//end else, paper
                break;

        }
        }


    }
